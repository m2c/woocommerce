== Installation ==

 * Unzip the files and upload the folder into your plugins folder (wp-content/plugins/)
 * Activate the plugin in your WordPress admin area.
 * Open the settings page for WooCommerce and click the gateways tab
 * Configure the merchant settings which is provided from Kiple  
 * WooCommerce Kiple is a Kiple payment gateway for WooCommerce v3.6.x, v3.7.x, v3.8.x, v3.9.x, v4.0.x
 
== Important Note ==

You *must* enable SSL from the settings panel to use this plugin in live mode - this is for your customers safety and security.



